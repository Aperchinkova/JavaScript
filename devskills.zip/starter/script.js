// Remember, we're gonna use strict mode in all scripts now!
"use strict";

// console.log(6);
// console.log(3333);

// const temp = [3 - 2, -6, -1, "error", 9, 13, 17, 15, 14, 9, 5];

// const calc = function (temp) {
//   let max = temp[0];
//   let min = temp[0];
//   for (let i = 0; i < temp.length; i++) {
//     const curTemp = temp[i];
//     if (curTemp > max) {
//       max = curTemp;
//     }
//     if (curTemp < min) {
//       min = curTemp;
//     }
//   }
//   console.log(max, min);
//   return max - min;
// };
// const result = calc(temp);
// console.log(result);

const f = function () {
  const m = {
    type: "kiki",
    unit: "celsius",
    value: Number(prompt("enter number: ")),
  };
  const sum = 273 + m.value;
  return sum;
};
console.log(f());
